<?php

        $this->watOptions = TitanFramework::getInstance( 'wat' );

        $blog_email = get_option('admin_email');
        $blog_from_name = get_option('blogname'); 
        $wps_options = unserialize(get_option('wat_options'));
        //get all admin users
        $user_query = new WP_User_Query( array( 'role' => 'Administrator' ) );
        if ( ! empty( $user_query->results ) ) {
                foreach ( $user_query->results as $user ) {
                        $admin_users[$user->ID] = $user->display_name;
                }
        }
        
        //initialize WAT themes
        $get_wat_themes = new WPSTHEMES();
        $wat_themes = $get_wat_themes->get_wat_themes();
        
        $wat_color_themes = array();
        foreach ($wat_themes as $wat_theme_name => $wat_theme) {
            $wat_theme_data = unserialize(base64_decode($wat_theme));
            unset($color_palette_preview);
            $color_palette_preview = '
                <div class="colors" style="float:right;display:inline-block;margin-top:-19px;margin-bottom:10px;">
                <table class="colors">
                    <tbody><tr>
                            <th>' . $wat_theme_name . '</th>
                            <td style="border:1px solid #e1e1e1;background-color: ' . $wat_theme_data['admin_bar_color'] . ' ">&nbsp;</td>
                            <td style="border:1px solid #e1e1e1;background-color: ' . $wat_theme_data['nav_wrap_color'] . '">&nbsp;</td>
                            <td style="border:1px solid #e1e1e1;background-color: ' . $wat_theme_data['active_menu_color'] . '">&nbsp;</td>
                            <td style="border:1px solid #e1e1e1;background-color: ' . $wat_theme_data['pry_button_color'] . '">&nbsp;</td>
                            <td style="border:1px solid #e1e1e1;background-color: ' . $wat_theme_data['sec_button_color'] . '">&nbsp;</td>
                            </tr>
                    </tbody>
                </table></div>';
            $wat_color_themes[$wat_theme_name] = $color_palette_preview;
        }
	
	$watPanel = $this->watOptions->createAdminPanel( array(
		'name' => 'WAT Options',
		'title' => 'WAT Plugin',
		'icon' => 'dashicons-art',
		'capability' => 'administrator',
	) );
	
	$generalTab = $watPanel->createTab( array(
		'name' => __( 'General', 'wat' ),
		'id' => 'general_options',
	));
	
	$loginTab = $watPanel->createTab( array(
		'name' => __( 'Login Page', 'wat' ),
		'id' => 'login_options',
	));
	$dashTab = $watPanel->createTab( array(
		'name' => __( 'Dashboard', 'wat' ),
		'id' => 'dash_options',
	));
	$adminbarTab = $watPanel->createTab( array(
		'name' => __( 'Adminbar', 'wat' ),
		'id' => 'adminbar_options',
	));
	$adminTab = $watPanel->createTab( array(
		'name' => __( 'Admin Pages', 'wat' ),
		'id' => 'admin_options',
	));
	$footerTab = $watPanel->createTab( array(
		'name' => __( 'Footer', 'wat' ),
		'id' => 'footer_options',
	));
	$fontsTab = $watPanel->createTab( array(
		'name' => __( 'Fonts', 'wat' ),
		'id' => 'fonts_options',
	));
                    $themesTab = $watPanel->createTab( array(
		'name' => __( 'Themes', 'wat' ),
		'id' => 'themes_options',
	));
	
	//ThemesTab Options
                    $themesTab->createOption( array(
                        'type' => 'note',
                        'desc' => __( 'Note: Importing a theme will replace your existing custom set colors! <strong>Refresh the page after importing a theme because sometimes the old css may still be present in your browser cache.</strong>', 'wat'),
                    ) );
                    
                    $themesTab->createOption( array(
                        'name' => __('Select a Theme', 'wat'),
                        'id' => 'import_theme',
                        'options' => $wat_color_themes,
                        'type' => 'radio',
                    ) );
                    
                    $themesTab->createOption( array(
		'type' => 'save'
	) );
                    
	//AdminTab Options
	$adminTab->createOption( array(
		'name' => __( 'Admin Menu Color options', 'wat' ),
		'type' => 'heading',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Background color', 'wat' ),
		'id' => 'bg_color',
		'type' => 'color',
		'default' => '#e3e7ea',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Left menu wrap color', 'wat' ),
		'id' => 'nav_wrap_color',
		'type' => 'color',
		'default' => '#1b2831',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Submenu wrap color', 'wat' ),
		'id' => 'sub_nav_wrap_color',
		'type' => 'color',
		'default' => '#22303a',
	) );	
	$adminTab->createOption( array(
		'name' => __( 'Menu hover color', 'wat' ),
		'id' => 'hover_menu_color',
		'type' => 'color',
		'default' => '#3f4457',
	) );	
	$adminTab->createOption( array(
		'name' => __( 'Current active Menu color', 'wat' ),
		'id' => 'active_menu_color',
		'type' => 'color',
		'default' => '#6da87a',
	) );	
	$adminTab->createOption( array(
		'name' => __( 'Menu text color', 'wat' ),
		'id' => 'nav_text_color',
		'type' => 'color',
		'default' => '#90a1a8',
	) );	
	$adminTab->createOption( array(
		'name' => __( 'Menu hover text color', 'wat' ),
		'id' => 'menu_hover_text_color',
		'type' => 'color',
		'default' => '#ffffff',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Updates Count notification background', 'wat' ),
		'id' => 'menu_updates_count_bg',
		'type' => 'color',
		'default' => '#212121',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Updates Count text color', 'wat' ),
		'id' => 'menu_updates_count_text',
		'type' => 'color',
		'default' => '#ffffff',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Primary button colors', 'wat' ),
		'type' => 'heading',
	) );	
	$adminTab->createOption( array(
		'name' => __( 'Button background  color', 'wat' ),
		'id' => 'pry_button_color',
		'type' => 'color',
		'default' => '#7ac600',
	) );
	if(isset($wps_options['design_type']) && $wps_options['design_type'] != "flat") {
		$adminTab->createOption( array(
			'name' => __( 'Button border color', 'wat' ),
			'id' => 'pry_button_border_color',
			'type' => 'color',
			'default' => '#86b520',
		) );
		$adminTab->createOption( array(
			'name' => __( 'Button shadow color', 'wat' ),
			'id' => 'pry_button_shadow_color',
			'type' => 'color',
			'default' => '#98ce23',
		) );
	}
	$adminTab->createOption( array(
		'name' => __( 'Button text color', 'wat' ),
		'id' => 'pry_button_text_color',
		'type' => 'color',
		'default' => '#ffffff',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Button hover background color', 'wat' ),
		'id' => 'pry_button_hover_color',
		'type' => 'color',
		'default' => '#29ac39',
	) );
	if(isset($wps_options['design_type']) && $wps_options['design_type'] != "flat") {
		$adminTab->createOption( array(
			'name' => __( 'Button hover border color', 'wat' ),
			'id' => 'pry_button_hover_border_color',
			'type' => 'color',
			'default' => '#259633',
		) );
		$adminTab->createOption( array(
			'name' => __( 'Button hover shadow color', 'wat' ),
			'id' => 'pry_button_hover_shadow_color',
			'type' => 'color',
			'default' => '#3d7a0c',
		) );
	}
	$adminTab->createOption( array(
		'name' => __( 'Button hover text color', 'wat' ),
		'id' => 'pry_button_hover_text_color',
		'type' => 'color',
		'default' => '#ffffff',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Secondary button colors', 'wat' ),
		'type' => 'heading',
	) );	
	$adminTab->createOption( array(
		'name' => __( 'Button background color', 'wat' ),
		'id' => 'sec_button_color',
		'type' => 'color',
		'default' => '#ced6c9',
	) );
	if(isset($wps_options['design_type']) && $wps_options['design_type'] != "flat") {
		$adminTab->createOption( array(
			'name' => __( 'Button border color', 'wat' ),
			'id' => 'sec_button_border_color',
			'type' => 'color',
			'default' => '#bdc4b8',
		) );
		$adminTab->createOption( array(
			'name' => __( 'Button shadow color', 'wat' ),
			'id' => 'sec_button_shadow_color',
			'type' => 'color',
			'default' => '#dde5d7',
		) );
	}
	$adminTab->createOption( array(
		'name' => __( 'Button text color', 'wat' ),
		'id' => 'sec_button_text_color',
		'type' => 'color',
		'default' => '#7a7a7a',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Button hover background color', 'wat' ),
		'id' => 'sec_button_hover_color',
		'type' => 'color',
		'default' => '#c9c8bf',
	) );
	if(isset($wps_options['design_type']) && $wps_options['design_type'] != "flat") {
		$adminTab->createOption( array(
			'name' => __( 'Button hover border color', 'wat' ),
			'id' => 'sec_button_hover_border_color',
			'type' => 'color',
			'default' => '#babab0',
		) );
		$adminTab->createOption( array(
			'name' => __( 'Button hover shadow color', 'wat' ),
			'id' => 'sec_button_hover_shadow_color',
			'type' => 'color',
			'default' => '#9ea59b',
		) );
	}
	$adminTab->createOption( array(
		'name' => __( 'Button hover text color', 'wat' ),
		'id' => 'sec_button_hover_text_color',
		'type' => 'color',
		'default' => '#ffffff',
	) );	
	
	$adminTab->createOption( array(
		'name' => __( 'Add New button', 'wat' ),
		'type' => 'heading',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Button background color', 'wat' ),
		'id' => 'addbtn_bg_color',
		'type' => 'color',
		'default' => '#53D860',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Button hover background color', 'wat' ),
		'id' => 'addbtn_hover_bg_color',
		'type' => 'color',
		'default' => '#5AC565',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Button text color', 'wat' ),
		'id' => 'addbtn_text_color',
		'type' => 'color',
		'default' => '#ffffff',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Button hover text color', 'wat' ),
		'id' => 'addbtn_hover_text_color',
		'type' => 'color',
		'default' => '#ffffff',
	) );
	
	$adminTab->createOption( array(
		'name' => __( 'Metabox Colors', 'wat' ),
		'type' => 'heading',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Metabox header box', 'wat' ),
		'id' => 'metabox_h3_color',
		'type' => 'color',
		'default' => '#bdbdbd',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Metabox header box border', 'wat' ),
		'id' => 'metabox_h3_border_color',
		'type' => 'color',
		'default' => '#9e9e9e',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Metabox header Click button color', 'wat' ),
		'id' => 'metabox_handle_color',
		'type' => 'color',
		'default' => '#ffffff',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Metabox header Click button hover color', 'wat' ),
		'id' => 'metabox_handle_hover_color',
		'type' => 'color',
		'default' => '#949494',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Metabox header text color', 'wat' ),
		'id' => 'metabox_text_color',
		'type' => 'color',
		'default' => '#ffffff',
	) );
	
	$adminTab->createOption( array(
		'name' => __( 'Message box (Post/Page updates)', 'wat' ),
		'type' => 'heading',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Message box color', 'wat' ),
		'id' => 'msg_box_color',
		'type' => 'color',
		'default' => '#02c5cc',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Message text color', 'wat' ),
		'id' => 'msgbox_text_color',
		'type' => 'color',
		'default' => '#ffffff',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Message box border color', 'wat' ),
		'id' => 'msgbox_border_color',
		'type' => 'color',
		'default' => '#007e87',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Message link color', 'wat' ),
		'id' => 'msgbox_link_color',
		'type' => 'color',
		'default' => '#efefef',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Message link hover color', 'wat' ),
		'id' => 'msgbox_link_hover_color',
		'type' => 'color',
		'default' => '#e5e5e5',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Custom CSS', 'wat' ),
		'type' => 'heading',
	) );
	$adminTab->createOption( array(
		'name' => __( 'Custom CSS for Admin pages', 'wat' ),
		'id' => 'admin_page_custom_css',
		'type' => 'textarea',
	) );
	
	
	$adminTab->createOption( array(
		'type' => 'save'
	) );
	
	//AdminBar Options
	/*$adminbarTab->createOption( array(
		'name' => 'Admin Title',
		'id' => 'admin_title',
		'type' => 'text',
	) );*/

	$adminbarTab->createOption( array(
		'name' => __( 'Upload Logo', 'wat' ),
		'id' => 'admin_logo',
		'type' => 'upload',
		'desc' => __( 'Image to be displayed in all pages. Maximum size 200x50 pixels.', 'wat' ),
	) );
	
	$adminbarTab->createOption( array(
		'name' => __( 'Move logo Top by', 'wat' ),
		'id' => 'logo_top_margin',
		'type' => 'number',
		'desc' => __( 'Can be used in case of logo position does not match the menu position.', 'wat' ),
		'default' => '0',
		'max' => '20',
	) );
	
	$adminbarTab->createOption( array(
		'name' => __( 'Move logo Bottom by', 'wat' ),
		'id' => 'logo_bottom_margin',
		'type' => 'number',
		'desc' => __( 'Can be used in case of logo position does not match the menu position.', 'wat' ),
		'default' => '0',
		'max' => '20',
	) );
        
                    $adminbarTab->createOption( array(
		'name' => __( 'Move logo Right by', 'wat' ),
		'id' => 'logo_left_margin',
		'type' => 'number',
		'default' => '0',
                                        'min' => '20',
		'max' => '150',
	) );
	
	$adminbarTab->createOption( array(
		'name' => __( 'Logo background color', 'wat' ),
		'id' => 'logo_bg_color',
		'type' => 'color',
		'default' => '#24343F',
	) );
	
	$adminbarTab->createOption( array(
		'name' => __( 'Admin bar color', 'wat' ),
		'id' => 'admin_bar_color',
		'type' => 'color',
		'default' => '#fff',
	) );
	
	$adminbarTab->createOption( array(
		'name' => __( 'Admin bar menu color', 'wat' ),
		'id' => 'admin_bar_menu_color',
		'type' => 'color',
		'default' => '#94979B',
	) );
	
	$adminbarTab->createOption( array(
		'name' => __( 'Admin bar menu hover color', 'wat' ),
		'id' => 'admin_bar_menu_hover_color',
		'type' => 'color',
		'default' => '#474747',
	) );
	
	$adminbarTab->createOption( array(
		'name' => __( 'Remove Unwanted Menus', 'wat' ),
		'id' => 'hide_admin_bar_menus',
		'type' => 'multicheck',
		'desc' => __( 'Select whichever you want to remove.', 'wat' ),
		'options' => array(
			'1' => 'Site Name',
			'2' => 'Updates',					
			'3' => 'Comments',
			'4' => 'New Content',
			'5' => 'Edit Profile',
			'6' => 'My account',
			'7' => 'WordPress Logo',
		),
		'default' => array( '3', '4', '7' ),
	) );
	
	$adminbarTab->createOption( array(
		'type' => 'save'
	) );
	
	//Login Page Options
	$loginTab->createOption( array(
		'name' => __( 'Background color', 'wat' ),
		'id' => 'login_bg_color',
		'type' => 'color',
		'default' => '#292931',
	) );

	$loginTab->createOption( array(
		'name' => __( 'Background image', 'wat' ),
		'id' => 'login_bg_img',
		'type' => 'upload',
	) );
	$loginTab->createOption( array(
		'name' => __( 'Background Repeat', 'wat' ),
		'id' => 'login_bg_img_repeat',
		'type' => 'checkbox',
		'desc' => __( 'Check to repeat', 'wat' ),
		'default' => true,
	) );	
	$loginTab->createOption( array(
		'name' => __( 'Scale background image', 'wat' ),
		'id' => 'login_bg_img_scale',
		'type' => 'checkbox',
		'desc' => __( 'Scale image to fit Screen size.', 'wat' ),
		'default' => true,
	) );
	$loginTab->createOption( array(
		'name' => __( 'Login Form Top margin', 'wat' ),
		'id' => 'login_form_margintop',
		'type' => 'number',
		'default' => '100',
		'min' => '0',
		'max' => '700',
	) );
	$loginTab->createOption( array(
		'name' => __( 'Login Form Width(%)', 'wat' ),
		'id' => 'login_form_width',
		'type' => 'number',
		'default' => '30',
		'min' => '20',
		'max' => '100',
	) );

	$loginTab->createOption( array(
	'name' => __( 'Upload Logo', 'wat' ),
	'id' => 'admin_login_logo',
	'type' => 'upload',
	'desc' => __( 'Image to be displayed on login page. Maximum width should be under 450pixels.', 'wat' ),
	) );

	$loginTab->createOption( array(
		'name' => __( 'Resize Logo?', 'wat' ),
		'id' => 'admin_logo_resize',
		'type' => 'checkbox',
		'default' => false,
		'desc' => __( 'Select to resize logo size.', 'wat' ),
	) );
	$loginTab->createOption( array(
		'name' => __( 'Set Logo size (%)', 'wat' ),
		'id' => 'admin_logo_size_percent',
		'type' => 'number',
		'default' => '1',
		'max' => '100',
	) );
	$loginTab->createOption( array(
		'name' => __( 'Logo Height', 'wat' ),
		'id' => 'admin_logo_height',
		'type' => 'number',
		'default' => '50',
		'max' => '150',
	) );
	$loginTab->createOption( array(
		'name' => __( 'Logo url', 'wat' ),
		'id' => 'login_logo_url',
		'type' => 'text',
		'default' => get_bloginfo('url'),
	) );
	$loginTab->createOption( array(
		'name' => __( 'Transparent Form', 'wat' ),
		'id' => 'login_divbg_transparent',
		'type' => 'checkbox',
		'default' => false,
		'desc' => __( 'Select to show transparent form background.', 'wat' ),
	) );
	$loginTab->createOption( array(
		'name' => __( 'Login div bacground color', 'wat' ),
		'id' => 'login_divbg_color',
		'type' => 'color',
		'default' => '#f5f5f5',
	) );
	$loginTab->createOption( array(
		'name' => __( 'Login form bacground color', 'wat' ),
		'id' => 'login_formbg_color',
		'type' => 'color',
		'default' => '#423143',
	) );
	$loginTab->createOption( array(
		'name' => __( 'Form border color', 'wat' ),
		'id' => 'form_border_color',
		'type' => 'color',
		'default' => '#e5e5e5',
	) );
	$loginTab->createOption( array(
		'name' => __( 'Form text color', 'wat' ),
		'id' => 'form_text_color',
		'type' => 'color',
		'default' => '#cccccc',
	) );
	$loginTab->createOption( array(
		'name' => __( 'Form link color', 'wat' ),
		'id' => 'form_link_color',
		'type' => 'color',
		'default' => '#777777',
	) );
	$loginTab->createOption( array(
		'name' => __( 'Form link hover color', 'wat' ),
		'id' => 'form_link_hover_color',
		'type' => 'color',
		'default' => '#555555',
	) );
	$loginTab->createOption( array(
		'name' => __( 'Hide "Back to blog link"', 'wat' ),
		'id' => 'hide_backtoblog',
		'type' => 'checkbox',
		'default' => false,
		'desc' => __( 'select to hide', 'wat' ),
	) );
	$loginTab->createOption( array(
		'name' => __( 'Hide "Remember me"', 'wat' ),
		'id' => 'hide_remember',
		'type' => 'checkbox',
		'default' => false,
		'desc' => __( 'select to hide', 'wat' ),
	) );
	$loginTab->createOption( array(
		'name' => __( 'Custom Footer content', 'wat' ),
		'id' => 'login_footer_content',
		'type' => 'editor',
	) );
	$loginTab->createOption( array(
		'name' => __( 'Custom CSS', 'wat' ),
		'type' => 'heading',
	) );
	$loginTab->createOption( array(
		'name' => __( 'Custom CSS for Login page', 'wat' ),
		'id' => 'login_custom_css',
		'type' => 'textarea',
	) );
	
	$loginTab->createOption( array(
		'type' => 'save'
	) );
	
	$generalTab->createOption( array(
		'name' => __( 'General options', 'wat' ),
		'type' => 'heading',
	) );
	$generalTab->createOption( array(
		'name' => __( 'Choose design type', 'wat' ),
		'id' => 'design_type',
		'type' => 'radio',
		'options' => array(
			'flat' => 'Flat design',
			'default' => 'Default design',
		),
		'default' => 'flat',
	) );
	$generalTab->createOption( array(
		'name' => __( 'Remove unwanted items', 'wat' ),
		'id' => 'admin_generaloptions',
		'type' => 'multicheck',
		'desc' => __( 'Select whichever you want to remove.', 'wat' ),
		'options' => array(
			'1' => 'Wordpress Help tab.',					
			'2' => 'Screen Options.',
			'3' => 'Wordpress update notifications.',
		),
	) );
                    $generalTab->createOption( array(
		'name' => __( 'Disable automatic updates', 'wps' ),
		'id' => 'disable_auto_updates',
		'type' => 'checkbox',
		'desc' => __( 'Select to disable all automatic background updates.', 'wps' ),
		'default' => false,
	) );
	$generalTab->createOption( array(
		'name' => __( 'Disable update emails', 'wps' ),
		'id' => 'disable_update_emails',
		'type' => 'checkbox',
		'desc' => __( 'Select to disable emails regarding automatic updates.', 'wps' ),
		'default' => false,
	) );
	$generalTab->createOption( array(
		'name' => __( 'Hide Admin bar', 'wat' ),
		'id' => 'hide_admin_bar',
		'type' => 'checkbox',
		'desc' => __( 'Select to hideadmin bar on frontend.', 'wat' ),
		'default' => true,
	) );

	$generalTab->createOption( array(
		'name' => __( 'Hide Color picker from user profile', 'wat' ),
		'id' => 'hide_profile_color_picker',
		'type' => 'checkbox',
		'desc' => __( 'Select to hide Color picker from user profile.', 'wat' ),
		'default' => true,
	) );
	
	$generalTab->createOption( array(
		'name' => __( 'Menu Customization options', 'wat' ),
		'type' => 'heading',
	) );
                    $generalTab->createOption( array(
		'name' => __( 'Menu Type', 'wat' ),
		'id' => 'admin_menu_type',
		'type' => 'radio',
		'options' => array(
			'menusl' => 'Sliding menu',
			'menuho' => 'Default hover menu',
		),
	) );
	$generalTab->createOption( array(
		'name' => __( 'Menu display', 'wat' ),
		'id' => 'show_all_menu_to_admin',
		'type' => 'radio',
		'options' => array(
			'1' => 'Show all Menu links to all admin users',
			'2' => 'Show all Menu links to specific admin users',
		),
	) );
	$generalTab->createOption( array(
		'name' => __( 'Select Privilege users', 'wat' ),
		'id' => 'privilege_users',
		'type' => 'multicheck',
		'desc' => __( 'Select admin users who can have access to all menu items.', 'wat' ),
		'options' => $admin_users,
	) );
	$generalTab->createOption( array(
		'type' => 'save'
	) );
	
	
	$dashTab->createOption( array(
		'name' => __( 'Remove unwanted Widgets', 'wat' ),
		'id' => 'remove_dash_widgets',
		'type' => 'multicheck',
		'desc' => __( 'Select whichever you want to remove.', 'wat' ),
		'options' => array(
			'1' => 'Welcome panel',					
			'2' => 'Right now',
			'3' => 'Recent activity',
			'4' => 'Incoming links',
			'5' => 'Plugins',
			'6' => 'Quick press',
			'7' => 'Recent drafts',
			'8' => 'Wordpress news',
			'9' => 'Wordpress blog',
			'10' => 'bbPress',
			'11' => 'Yoast seo',
			'12' => 'Gravity forms',
		),
		'default' => array( '8', '9' ),
	) );	
	$dashTab->createOption( array(
		'name' => __( 'Create New Widgets', 'wat' ),
		'type' => 'heading',
	) );
	$dashTab->createOption( array(
		'type' => 'note',
		'desc' => __( 'Widget 1', 'wat' ),
	) );
	$dashTab->createOption( array(
		'name' => __( 'Widget Type', 'wat' ),
		'id' => 'wps_widget_1_type',
		'options' => array(
        '1' => 'RSS Feed',
        '2' => 'Text Content',
		),
		'type' => 'radio',
		'default' => '1',
	) );
	$dashTab->createOption( array(
		'name' => __( 'Widget Position', 'wat' ),
		'id' => 'wps_widget_1_position',
		'options' => array(
		'normal' => 'Left',
		'side' => 'Right',
		),
		'type' => 'select',
	) );
	$dashTab->createOption( array(
		'name' => __( 'Widget Title', 'wat' ),
		'id' => 'wps_widget_1_title',
		'type' => 'text',
	) );
	$dashTab->createOption( array(
		'name' => __( 'RSS Feed url', 'wat' ),
		'id' => 'wps_widget_1_rss',
		'type' => 'text',
		'desc' => __( 'Put your RSS feed url here if you want to show your own RSS feeds. Otherwise fill your static contents in the below editor.', 'wat' ),
	) );
	$dashTab->createOption( array(
		'name' => __( 'Widget Content', 'wat' ),
		'id' => 'wps_widget_1_content',
		'type' => 'editor',
	) );
	
	$dashTab->createOption( array(
		'type' => 'note',
		'desc' => __( 'Widget 2', 'wat' ),
	) );
	$dashTab->createOption( array(
		'name' => __( 'Widget Type', 'wat' ),
		'id' => 'wps_widget_2_type',
		'options' => array(
		'1' => 'RSS Feed',
		'2' => 'Text Content',
		),
		'type' => 'radio',
		'default' => '1',
	) );
	$dashTab->createOption( array(
		'name' => __( 'Widget Position', 'wat' ),
		'id' => 'wps_widget_2_position',
		'options' => array(
		'normal' => 'Left',
		'side' => 'Right',
		),
		'type' => 'select',
	) );
	$dashTab->createOption( array(
		'name' => __( 'Widget Title', 'wat' ),
		'id' => 'wps_widget_2_title',
		'type' => 'text',
	) );
	$dashTab->createOption( array(
		'name' => __( 'RSS Feed url', 'wat' ),
		'id' => 'wps_widget_2_rss',
		'type' => 'text',
		'desc' => __( 'Put your RSS feed url here if you want to show your own RSS feeds. Otherwise fill your static contents in the below editor.', 'wat' ),
	) );
	$dashTab->createOption( array(
		'name' =>  __( 'Widget Content', 'wat' ),
		'id' => 'wps_widget_2_content',
		'type' => 'editor',
	) );
	
	$dashTab->createOption( array(
		'type' => 'note',
		'desc' => __( 'Widget 3', 'wat' ),
	) );
	$dashTab->createOption( array(
		'name' => __( 'Widget Type', 'wat' ),
		'id' => 'wps_widget_3_type',
		'options' => array(
        '1' => 'RSS Feed',
        '2' => 'Text Content',
		),
		'type' => 'radio',
		'default' => '1',
	) );
	$dashTab->createOption( array(
		'name' => __( 'Widget Position', 'wat' ),
		'id' => 'wps_widget_3_position',
		'options' => array(
        'normal' => 'Left',
        'side' => 'Right',
		),
		'type' => 'select',
	) );
	$dashTab->createOption( array(
		'name' => __( 'Widget Title', 'wat' ),
		'id' => 'wps_widget_3_title',
		'type' => 'text',
	) );
	$dashTab->createOption( array(
		'name' => __( 'RSS Feed url', 'wat' ),
		'id' => 'wps_widget_3_rss',
		'type' => 'text',
		'desc' => __( 'Put your RSS feed url here if you want to show your own RSS feeds. Otherwise fill your static contents in the below editor.', 'wat' ),
	) );
	$dashTab->createOption( array(
		'name' => __( 'Widget Content', 'wat' ),
		'id' => 'wps_widget_3_content',
		'type' => 'editor',
	) );
	
	$dashTab->createOption( array(
		'type' => 'note',
		'desc' => __( 'Widget 4', 'wat' ),
	) );
	$dashTab->createOption( array(
		'name' => __( 'Widget Type', 'wat' ),
		'id' => 'wps_widget_4_type',
		'options' => array(
        '1' => 'RSS Feed',
        '2' => 'Text Content',
		),
		'type' => 'radio',
		'default' => '1',
	) );
	$dashTab->createOption( array(
		'name' => __( 'Widget Position', 'wat' ),
		'id' => 'wps_widget_4_position',
		'options' => array(
        'normal' => 'Left',
        'side' => 'Right',
		),
		'type' => 'select',
	) );
	$dashTab->createOption( array(
		'name' => __( 'Widget Title', 'wat' ),
		'id' => 'wps_widget_4_title',
		'type' => 'text',
	) );
	$dashTab->createOption( array(
		'name' => __( 'RSS Feed url', 'wat' ),
		'id' => 'wps_widget_4_rss',
		'type' => 'text',
		'desc' => __( 'Put your RSS feed url here if you want to show your own RSS feeds. Otherwise fill your static contents in the below editor.', 'wat' ),
	) );
	$dashTab->createOption( array(
		'name' => __( 'Widget Content', 'wat' ),
		'id' => 'wps_widget_4_content',
		'type' => 'editor',
	) );

	$dashTab->createOption( array(
		'type' => 'save'
	) );
	
	$footerTab->createOption( array(
		'name' => __( 'Footer Text', 'wat' ),
		'id' => 'admin_footer_txt',
		'type' => 'editor',
		'desc' => __( 'Put any text you want to show on admin footer.', 'wat' ),
	) );
	$footerTab->createOption( array(
		'type' => 'save'
	) );
	
	$fontsTab->createOption( array(
		'name' => __( 'Font options', 'wat' ),
		'type' => 'heading',
	) );
	$fontsTab->createOption( array(
		'name' => 'Body Content Font',
		'id' => 'admin_body_font',
		'type' => 'font',
		'desc' => 'Select a style',
		'show_line_height' => false,
		'show_letter_spacing' => false,
		'show_text_transform' => false,
		'show_font_variant' => false,
		'show_text_shadow' => false,
		'show_font_size' => false,
		'default' => array(
			'font-family' => 'Open Sans',
			'line-height' => '1em',
			'font-weight' => '300',
			'color' => '#444444',
		)
	) );
	$fontsTab->createOption( array(
		'name' => 'Heading H1',
		'id' => 'admin_h1_font',
		'type' => 'font',
		'desc' => 'Select a style',
		'show_line_height' => false,
		'show_letter_spacing' => false,
		'show_font_variant' => false,
		'show_font_style' => false,
		'show_text_shadow' => false,
		'default' => array(
			'font-family' => 'Droid Sans',
			'font-size' => '24px',
			'color' => '#333333',
			'line-height' => '1em',
			'font-weight' => '300',
		)
	) );
	$fontsTab->createOption( array(
		'name' => 'Heading H2',
		'id' => 'admin_h2_font',
		'type' => 'font',
		'desc' => 'Select a style',
		'show_line_height' => false,
		'show_letter_spacing' => false,
		'show_font_variant' => false,
		'show_font_style' => false,
		'show_text_shadow' => false,
		'default' => array(
			'font-family' => 'Droid Sans',
			'font-size' => '20px',
			'color' => '#333333',
			'line-height' => '1em',
			'font-weight' => '300',
		)
	) );
	$fontsTab->createOption( array(
		'name' => 'Heading H3',
		'id' => 'admin_h3_font',
		'type' => 'font',
		'desc' => 'Select a style',
		'show_line_height' => false,
		'show_letter_spacing' => false,
		'show_font_variant' => false,
		'show_font_style' => false,
		'show_text_shadow' => false,
		'default' => array(
			'font-family' => 'Droid Sans',
			'font-size' => '18px',
			'color' => '#333333',
			'line-height' => '1em',
			'font-weight' => '300',
		)
	) );
	$fontsTab->createOption( array(
		'name' => 'Heading H4',
		'id' => 'admin_h4_font',
		'type' => 'font',
		'desc' => 'Select a style',
		'show_line_height' => false,
		'show_letter_spacing' => false,
		'show_font_variant' => false,
		'show_font_style' => false,
		'show_text_shadow' => false,
		'default' => array(
			'font-family' => 'Droid Sans',
			'font-size' => '16px',
			'color' => '#333333',
			'line-height' => '1em',
			'font-weight' => '300',
		)
	) );
	$fontsTab->createOption( array(
		'name' => 'Heading H5',
		'id' => 'admin_h5_font',
		'type' => 'font',
		'desc' => 'Select a style',
		'show_line_height' => false,
		'show_letter_spacing' => false,
		'show_font_variant' => false,
		'show_font_style' => false,
		'show_text_shadow' => false,
		'default' => array(
			'font-family' => 'Droid Sans',
			'font-size' => '14px',
			'color' => '#333333',
			'line-height' => '1em',
			'font-weight' => '300',
		)
	) );
	$fontsTab->createOption( array(
		'name' => 'Heading H6',
		'id' => 'admin_h6_font',
		'type' => 'font',
		'desc' => 'Select a style',
		'show_line_height' => false,
		'show_letter_spacing' => false,
		'show_font_variant' => false,
		'show_font_style' => false,
		'show_text_shadow' => false,
		'default' => array(
			'font-family' => 'Droid Sans',
			'font-size' => '14px',
			'color' => '#333333',
			'line-height' => '1em',
			'font-weight' => '300',
		)
	) );
	$fontsTab->createOption( array(
		'name' => 'Menu Font',
		'id' => 'admin_menu_font',
		'type' => 'font',
		'desc' => 'Select a style',
		'show_line_height' => false,
		'show_letter_spacing' => false,
		'show_font_variant' => false,
		'show_text_shadow' => false,
		'show_font_size' => false,
		'show_color' => false,
		'default' => array(
			'font-family' => 'Droid Sans',
			'font-size' => '13px',
			'line-height' => '1em',
			'font-weight' => '300',
		)
	) );
	
	$fontsTab->createOption( array(
		'type' => 'save',
	) );
        
        /*
                    $wat_iconstyles = $this->wpsiconStyles();
                    $admin_page_custom_styles = $wps_options['admin_page_custom_css'];
                    $admin_login_custom_styles = $wps_options['login_custom_css'];
        
        $css_rules = "
                                        html, #wp-content-editor-tools {
                                                            background: \$bg_color;
}
                                        body {
                                                            font-family: \$admin_body_font-font-family;
			color: \$admin_body_font-color;
                                        }

		h1 {
			font-family: \$admin_h1_font-font-family;
			font-size: \$admin_h1_font-font-size;
			color: \$admin_h1_font-color;
			line-height: \$admin_h1_font-line-height;
			font-weight: \$admin_h1_font-font-weight;
		}

		h2 {
			font-family: \$admin_h2_font-font-family;
			font-size: \$admin_h2_font-font-size;
			color: \$admin_h2_font-color;
			line-height: \$admin_h2_font-line-height;
			font-weight: \$admin_h2_font-font-weight;
		}
                                        h3 {
			font-family: \$admin_h3_font-font-family;
			font-size: \$admin_h3_font-font-size;
			color: \$admin_h3_font-color;
			line-height: \$admin_h3_font-line-height;
			font-weight: \$admin_h3_font-font-weight;
		}
                                        h4 {
			font-family: \$admin_h4_font-font-family;
			font-size: \$admin_h4_font-font-size;
			color: \$admin_h4_font-color;
			line-height: \$admin_h4_font-line-height;
			font-weight: \$admin_h4_font-font-weight;
		}
                                        h5 {
			font-family: \$admin_h5_font-font-family;
			font-size: \$admin_h5_font-font-size;
			color: \$admin_h5_font-color;
			line-height: \$admin_h5_font-line-height;
			font-weight: \$admin_h5_font-font-weight;
		}
                                        h6 {
			font-family: \$admin_h6_font-font-family;
			font-size: \$admin_h6_font-font-size;
			color: \$admin_h6_font-color;
			line-height: \$admin_h6_font-line-height;
			font-weight: \$admin_h6_font-font-weight;
		}
                
                                         #wpadminbar * {
                                                            font-family: \$admin_menu_font-font-family;
			text-transform: \$admin_menu_font-text-transform;
                                        }
                                        
                                        #wpadminbar, #wpadminbar .menupop .ab-sub-wrapper, .ab-sub-secondary, #wpadminbar .quicklinks .menupop ul.ab-sub-secondary, #wpadminbar .quicklinks .menupop ul.ab-sub-secondary .ab-submenu { 
                                                            background: \$admin_bar_color;
                                        }
                                        
                                        #wpadminbar a.ab-item, #wpadminbar>#wp-toolbar span.ab-label, #wpadminbar>#wp-toolbar span.noticon, #wpadminbar .ab-icon:before, #wpadminbar .ab-item:before {
                                                            color: \$admin_bar_menu_color;
                                        }
                                        
                                        div#wpadminbar li#wp-admin-bar-wat_site_title {
                                                            background-color:\$logo_bg_color;
                                        }
                                        
                                        #wpadminbar .ab-top-menu>li>.ab-item:focus, #wpadminbar.nojq .quicklinks .ab-top-menu>li>.ab-item:focus, #wpadminbar .ab-top-menu>li:hover>.ab-item, #wpadminbar .ab-top-menu>li.hover>.ab-item, #wpadminbar .quicklinks .menupop ul li a:focus, #wpadminbar .quicklinks .menupop ul li a:focus strong, #wpadminbar .quicklinks .menupop ul li a:hover, #wpadminbar-nojs .ab-top-menu>li.menupop:hover>.ab-item, #wpadminbar .ab-top-menu>li.menupop.hover>.ab-item, #wpadminbar .quicklinks .menupop ul li a:hover strong, #wpadminbar .quicklinks .menupop.hover ul li a:focus, #wpadminbar .quicklinks .menupop.hover ul li a:hover, #wpadminbar li .ab-item:focus:before, #wpadminbar li a:focus .ab-icon:before, #wpadminbar li.hover .ab-icon:before, #wpadminbar li.hover .ab-item:before, #wpadminbar li:hover #adminbarsearch:before, #wpadminbar li:hover .ab-icon:before, #wpadminbar li:hover .ab-item:before, #wpadminbar.nojs .quicklinks .menupop:hover ul li a:focus, #wpadminbar.nojs .quicklinks .menupop:hover ul li a:hover, #wpadminbar li:hover .ab-item:after, #wpadminbar>#wp-toolbar a:focus span.ab-label, #wpadminbar>#wp-toolbar li.hover span.ab-label, #wpadminbar>#wp-toolbar li:hover span.ab-label { 
                                                            color:\$admin_bar_menu_hover_color;
                                        }
                                        .quicklinks li.wat_site_title a{
                                                            margin-top: #{\$logo_top_margin}px;
                                                            margin-bottom: #{\$logo_bottom_margin}px;
                                                            margin-left:20px !important; outline:none; border:none;
                                        }

                                         #wpadminbar .ab-top-menu>li>.ab-item:focus, #wpadminbar-nojs .ab-top-menu>li.menupop:hover>.ab-item, #wpadminbar.nojq .quicklinks .ab-top-menu>li>.ab-item:focus, #wpadminbar .ab-top-menu>li:hover>.ab-item, #wpadminbar .ab-top-menu>li.menupop.hover>.ab-item, #wpadminbar .ab-top-menu>li.hover>.ab-item { background: none }

                                         .wp-core-ui .button,.wp-core-ui .button-secondary{
                                                            color:\$sec_button_text_color;
                                                            border-color:\$sec_button_border_color;
                                                            background:\$sec_button_color;
                                        }
                                        
                                        @if \$design_type == default {
                                             .wp-core-ui .button,.wp-core-ui .button-secondary{
                                                        -webkit-box-shadow:inset 0 1px 0 \$sec_button_shadow_color,0 1px 0 rgba(0,0,0,.08);box-shadow:inset 0 1px 0 \$sec_button_shadow_color,0 1px 0 rgba(0,0,0,.08);
                                              }
                                        }
                                             
                                        .wp-core-ui .button-secondary:focus, .wp-core-ui .button-secondary:hover, .wp-core-ui .button.focus, .wp-core-ui .button.hover, .wp-core-ui .button:focus, .wp-core-ui .button:hover {
                                                            color:\$sec_button_hover_text_color;
                                                            border-color:\$sec_button_hover_border_color;
                                                            background:\$sec_button_hover_color;
                                        }
                                        
                                        @if \$design_type == default {
                                            .wp-core-ui .button-secondary:focus, .wp-core-ui .button-secondary:hover, .wp-core-ui .button.focus, .wp-core-ui .button.hover, .wp-core-ui .button:focus, .wp-core-ui .button:hover {
                                                        -webkit-box-shadow:inset 0 1px 0 \$sec_button_hover_shadow_color,0 1px 0 rgba(0,0,0,.08);box-shadow:inset 0 1px 0 \$sec_button_hover_shadow_color,0 1px 0 rgba(0,0,0,.08); 
                                            }
                                        }
                                        
                                        .wp-core-ui .button-primary, .wp-core-ui .button-primary-disabled, .wp-core-ui .button-primary.disabled, .wp-core-ui .button-primary:disabled, .wp-core-ui .button-primary[disabled] {
                                                            background:\$pry_button_color !important; 
                                                            border-color:\$pry_button_border_color !important;
                                                            color:\$pry_button_text_color !important; 
                                        }
                                            
                                        @if \$design_type == default {
                                            .wp-core-ui .button-primary, .wp-core-ui .button-primary-disabled, .wp-core-ui .button-primary.disabled, .wp-core-ui .button-primary:disabled, .wp-core-ui .button-primary[disabled] {
                                                            -webkit-box-shadow:inset 0 1px 0 \$pry_button_shadow_color,0 1px 0 rgba(0,0,0,.15)!important; box-shadow: inset 0 1px 0 \$pry_button_shadow_color, 0 1px 0 rgba(0,0,0,.15)!important;
                                            }
                                        }
                                        
                                        .wp-core-ui .button-primary.focus, .wp-core-ui .button-primary.hover, .wp-core-ui .button-primary:focus, .wp-core-ui .button-primary:hover, .wp-core-ui .button-primary.active,.wp-core-ui .button-primary.active:focus,.wp-core-ui .button-primary.active:hover,.wp-core-ui .button-primary:active { 
                                                            background:\$pry_button_hover_color !important; 
                                                            border-color:\$pry_button_hover_border_color !important; 
                                                            color:\$pry_button_hover_text_color !important; 
                                        }
                                        
                                        @if \$design_type == default {
                                            .wp-core-ui .button-primary.focus, .wp-core-ui .button-primary.hover, .wp-core-ui .button-primary:focus, .wp-core-ui .button-primary:hover, .wp-core-ui .button-primary.active,.wp-core-ui .button-primary.active:focus,.wp-core-ui .button-primary.active:hover,.wp-core-ui .button-primary:active { 
                                                            -webkit-box-shadow:inset 0 1px 0 \$pry_button_hover_shadow_color,0 1px 0 rgba(0,0,0,.15) !important; box-shadow: inset 0 1px 0 $pry_button_hover_shadow_color,0 1px 0 rgba(0,0,0,.15) !important;
                                            }
                                        }
                                        
                                        #adminmenuback, #adminmenuwrap, #adminmenu { 
                                                            background:\$nav_wrap_color;
                                        }
                                        
                                        #adminmenu .wp-submenu-head, #adminmenu a.menu-top, #adminmenu .wp-submenu a {
                                                            font-family: \$admin_menu_font-font-family;
                                                            color:\$nav_text_color;
                                                            font-weight: \$admin_menu_font-font-weight !important;
                                                            text-transform: \$admin_menu_font-text-transform;
                                        }


                                        #adminmenu .wp-submenu a {
                                                            font-size: 0.9em !important
                                        }
                                        
                                        #adminmenu div.wp-menu-image:before, #adminmenu a, #adminmenu .wp-submenu a, #collapse-menu, #collapse-button div:after, #wpadminbar #wp-admin-bar-user-info .display-name, #wpadminbar>#wp-toolbar>#wp-admin-bar-root-default li:hover span.ab-label, li.wp-has-submenu > a:before { 
                                                            color:\$nav_text_color;
                                        }
                                        
                                        #adminmenu li:hover div.wp-menu-image:before, li.wp-has-submenu:hover > a:before, li.wp-has-submenu.wp-has-current-submenu > a:before{ 
                                                            color:\$menu_hover_text_color;
                                        }
                                        
                                        #adminmenu li.menu-top:hover, #adminmenu li.menu-top a:hover, #adminmenu li.opensub>a.menu-top, #adminmenu li>a.menu-top:focus {
                                                            background:\$hover_menu_color;
                                                            color:\$menu_hover_text_color;
                                        }
                                        
                                        #adminmenu li.wp-has-current-submenu a.wp-has-current-submenu, #adminmenu li.current a.menu-top, .folded #adminmenu li.wp-has-current-submenu, .folded #adminmenu li.current.menu-top, #adminmenu .wp-menu-arrow, #adminmenu .wp-has-current-submenu .wp-submenu .wp-submenu-head, #adminmenu .wp-menu-arrow div { 
                                                            background:\$active_menu_color;
                                        }
                                        
                                        #adminmenu .wp-submenu li.current a:focus, #adminmenu .wp-submenu li.current a:hover, #adminmenu a.wp-has-current-submenu:focus+.wp-submenu li.current a { 
                                                            color:\$menu_hover_text_color;
                                        }
                                        
                                        #adminmenu .wp-has-current-submenu .wp-submenu, .no-js li.wp-has-current-submenu:hover .wp-submenu, #adminmenu a.wp-has-current-submenu:focus+.wp-submenu, #adminmenu .wp-has-current-submenu .wp-submenu.sub-open, #adminmenu .wp-has-current-submenu.opensub .wp-submenu, #adminmenu .wp-not-current-submenu .wp-submenu, .folded #adminmenu .wp-has-current-submenu .wp-submenu{ 
                                                            background:\$sub_nav_wrap_color;
                                        }
                                        
                                        @if \$admin_menu_type == menusl {
                                            #adminmenuwrap {position:relative; margin:0px auto; padding:0px; height: 90%; overflow: auto; }
                                            #adminmenu .wp-submenu { display: none; position: relative; left: 0 !important; top: 0}
                                            #adminmenu li.wp-has-submenu > a:before  { position: absolute; right: 16px; top: 20px; line-height: 1; font-size: 10px; font-family: FontAwesome; height: auto; content: '\f067'; font-weight: normal; text-shadow: none; -webkit-transition: all 0.12s ease; transition: all 0.12s ease; }
                                            li.wp-has-submenu a.open:before {content: '\f068'; }
                                            ul#adminmenu a.wp-has-current-submenu:after, ul#adminmenu>li.current>a.current:after, #adminmenu li.wp-has-submenu.wp-not-current-submenu:hover:after { border: none;}
                                        }
                                        
                                        .folded #adminmenu .wp-has-current-submenu .wp-submenu { width: 200px; }
                                        
                                        #adminmenu .awaiting-mod, #adminmenu .update-plugins, #sidemenu li a span.update-plugins, #adminmenu li a.wp-has-current-submenu .update-plugins {
                                                            background-color:\$menu_updates_count_bg;
                                                            color:\$menu_updates_count_text;
                                        }                                        

                                        #wpadminbar .quicklinks .menupop ul li a, #wpadminbar .quicklinks .menupop ul li a strong, #wpadminbar .quicklinks .menupop.hover ul li a, #wpadminbar.nojs .quicklinks .menupop:hover ul li a {
                                                            color:\$admin_bar_menu_color;
                                                            font-size:13px !important;
                                        }
                                        
                                        #adminmenu .wp-menu-image img { padding: 6px 0 0 }
                                        
                                        .menu.ui-sortable .menu-item-handle, .meta-box-sortables.ui-sortable .hndle, .sortUls div.menu_handle, .wp-list-table thead, .menu-item-handle, .widget .widget-top { 
                                                            background:\$metabox_h3_color; 
                                                            border: 1px solid \$metabox_h3_border_color; 
                                                            color:\$metabox_text_color;
                                        }
                                        
                                        .postbox .hndle { border: none !important}
                                        
                                        ol.sortUls a.plus:before, ol.sortUls a.minus:before { 
                                                            color:\$metabox_handle_color;
                                        }
                        
                                        .postbox .accordion-section-title:after, .handlediv, .item-edit, .sidebar-name-arrow, .widget-action, .sortUls a.admin_menu_edit { 
                                                            color:\$metabox_handle_color;
                                        }                                        

                                        .postbox .accordion-section-title:hover:after, .handlediv:hover, .item-edit:hover, .sidebar-name:hover .sidebar-name-arrow, .widget-action:hover, .sortUls a.admin_menu_edit:hover { 
                                                            color:\$metabox_handle_hover_color;
                                        }
                                        
                                        .wp-list-table thead tr th, .wp-list-table thead tr th a, .wp-list-table thead tr th:hover, .wp-list-table thead tr th a:hover, span.sorting-indicator:before, span.comment-grey-bubble:before, .ui-sortable .item-type {
                                                            color:\$metabox_text_color;
                                        }
                                        
                                        .wrap .add-new-h2, .wrap .add-new-h2:active {
                                                            background-color:\$addbtn_bg_color;
                                                            color:\$addbtn_text_color;
                                        }
                                        
                                        .wrap .add-new-h2:hover {
                                                            background-color:\$addbtn_hover_bg_color;
                                                            color:\$addbtn_hover_text_color;
                                        }
                                        
                                        div.updated { 
                                                            border-left: 4px solid \$msgbox_border_color;
                                                            background-color:\$msg_box_color;
                                                            color:\$msgbox_text_color;
                                        }
                                        
                                        div.updated a {
                                                            color:\$msgbox_link_color;
                                        }
                                        
                                        div.updated a:hover {
                                                            color:\$msgbox_link_hover_color;
                                        }
                                        
                                        @if \$design_type == flat {
                                            .wp-core-ui .button-primary, #wpadminbar, .postbox,.wp-core-ui .button-primary.focus, .wp-core-ui .button-primary.hover, .wp-core-ui .button-primary:focus, .wp-core-ui .button-primary:hover, .wp-core-ui .button, .wp-core-ui .button-secondary, .wp-core-ui .button-secondary:focus, .wp-core-ui .button-secondary:hover, .wp-core-ui .button.focus, .wp-core-ui .button.hover, .wp-core-ui .button:focus, .wp-core-ui .button:hover, #wpadminbar .menupop .ab-sub-wrapper, #wpadminbar .shortlink-input, .theme-browser .theme { 
                                                    -webkit-box-shadow: none !important;
                                                    -moz-box-shadow: none !important;
                                                    box-shadow: none !important;
                                                    border: none;
                                            }
                                            input[type=checkbox], input[type=radio], #update-nag, .update-nag, .wp-list-table, .widefat, input[type=email], input[type=number], input[type=password], input[type=search], input[type=tel], input[type=text], input[type=url], select, textarea, #adminmenu .wp-submenu, .folded #adminmenu .wp-has-current-submenu .wp-submenu, .folded #adminmenu a.wp-has-current-submenu:focus+.wp-submenu, .mce-toolbar .mce-btn-group .mce-btn.mce-listbox, .wp-color-result, .widget-top, .widgets-holder-wrap { 
                                                    -webkit-box-shadow: none !important;
                                                    -moz-box-shadow: none !important;
                                                    box-shadow: none !important;
                                            } 
                                            body #dashboard-widgets .postbox form .submit { margin: 10px 0 !important; }
                                        }
                                        
                                        @if \$email_settings == 1 {
                                            tr.wat_email_from_addr, tr.wpshapere_email_from_name {
                                                display: none;
                                             }
                                        }
                                        @if \$show_all_menu_to_admin == 1 {
                                            tr.wat_privilege_users {
                                                display: none;
                                            }
                                        }
                                        

                                        body, html { 
                                                            height: auto;
                                        }
                                        
                                        html, body.login:after { 
                                                            display: block;
                                                            clear: both; 
                                        }
                                                            
                                        body.login-action-register { 
                                                            position: relative
                                        }                                        

                                        body.login-action-login, body.login-action-lostpassword { 
                                                            position: fixed 
                                        }                                
                                        
                                        .login h1 a{    
                                                            height:#{\$admin_logo_height}px; margin: 0 auto 20px;
                                        }

                                        body.interim-login div#login {
                                                            width: 95% !important;
                                                            height: auto 
                                        }
                                        
                                        .login label, .login form, .login form p { 
                                                            color:\$form_text_color !important; 
                                        }
                                        
                                        .login a { 
                                                            text-decoration: underline;
                                                            color:\$form_link_color !important; 
                                        }
                                        
                                        .login a:focus, .login a:hover { 
                                                            color:\$form_link_hover_color !important;
                                        }
                                        
                                        form#loginform .button-primary, form#registerform .button-primary, .button-primary {
                                                            background:\$pry_button_color !important; 
                                                            border-color:\$pry_button_border_color !important; 
                                                            color:\$pry_button_text_color !important;
                                        }
                                        
                                        form#loginform .button-primary.focus,form#loginform .button-primary.hover,form#loginform .button-primary:focus,form#loginform .button-primary:hover, form#registerform .button-primary.focus, form#registerform .button-primary.hover,form#registerform .button-primary:focus,form#registerform .button-primary:hover { 
                                                            background:\$pry_button_hover_color !important;
                                                            border-color:\$pry_button_hover_border_color !important;
                                        }                              

                                        input#user_login { 
                                                            background-position:7px -6px !important;
                                        }
                                        
                                        input#user_pass, input#user_email, input#pass1, input#pass2 { 
                                                            background-position:7px -56px !important;
                                        }
                                        
                                        .login form #wp-submit { 
                                                            width: 100%; height: 35px;
                                        }
                                        
                                        p.forgetmenot { 
                                                            margin-bottom: 16px !important;
                                        }
                                        
                                        .login #pass-strength-result {
                                                            margin: 12px 0 16px !important;
                                        }
                                        
                                        p.indicator-hint { 
                                                            clear:both;
                                        }
                                        
                                        .login_footer_content { 
                                                            padding: 20px 0; 
                                                            text-align:center;
                                        }
                                        
                                        @if \$design_type == flat {
                                                    .login .message, form#loginform .button-primary, form#registerform .button-primary, .button-primary, .wp-core-ui .button-primary { 
                                                        -webkit-box-shadow: none !important;
                                                        -moz-box-shadow: none !important;
                                                        box-shadow: none !important;
                                                        border: none !important;
                                                    }
                                        }

                                        @media only screen and (min-width: 800px) {
                                            div#login {
                                                    width: #{\$login_form_width}% !important;
                                            }
                                        }
                                        @media screen and (max-width: 800px){
                                            div#login {
                                                    width: 90% !important;
                                            }
                                            body.login {
                                                    background-size: auto;
                                            }
                                            body.login-action-login, body.login-action-lostpassword { 
                                                    position: relative; 
                                            }
                                        }

                                       
	" . $admin_page_custom_styles . $admin_login_custom_styles . $wat_iconstyles;

	$this->watOptions->createCSS($css_rules);
         * 
         */
        