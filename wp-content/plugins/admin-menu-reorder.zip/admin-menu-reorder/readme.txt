=== Admin Menu Reorder ===
Contributors: wpidiots
Tags: menu order, menu_order, custom_menu_order, custom menu order, admin menus, reorder, order, order administration menus, multisite, network, multiuser, multi user
Requires at least: 3.8
Tested up to: 3.8.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

 Easily reorder your admin menu items with simple drag & drop operation

== Description ==

Easily reorder your admin menu items on the user and blog level with simple drag & drop operation. 

Now every blog or network user may have own admin menu order according to their preference.

Don't forget to check our other [plugins](http://profiles.wordpress.org/wpidiots/)

== Installation ==

Quick Setup Steps

1. Upload `admin-menu-reorder` directory or extract `admin-menu-reorder.zip` file to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Reorder admin menu items by drag & drop

== Screenshots ==

1. Example of customized admin menu order

== Changelog ==

= 1.1 =
* Added support for custom-added menu items

= 1.0 =
* First Release